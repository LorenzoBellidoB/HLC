package ejercicio2;

public class Ejercicio2 {

	public static boolean esPar(int num) {
	
		boolean res = false;
		
		if(num % 2 == 0) {
			res = true;
		}
		return res;
	}
}
