package ejercicio7;

public class Ejercicio7 {

}
